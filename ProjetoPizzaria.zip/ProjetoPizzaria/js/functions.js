$(function(){
    $(".menu-mobile").click(function(){
        $(".menu-mobile ul li").slideToggle();
    });  

    $(document).ready(function(){
        
        var show = 3;        
        var w = $('#slider').width() / show;
        var l = $('.slide').length;     
        
        $('#slide-container').width(w * l);       
      
        function slider() {
         
          $('.slide').first().animate({
            marginLeft: -w - 300           
          }, 'slow', function() {
                       
            $(this).appendTo($(this).parent()).css({
              marginLeft: 0
            });
          });
        }
      
        var timer = setInterval(slider, 2000);
      
        $('#slider').hover(function() {         
          clearInterval(timer);
        }, function() {
            timer = setInterval(slider, 2000);
        });        
        
      
    }); 
    

    

    function menu(){
        var menuMid = $(".menu-mid ul li");
    
        menuMid.click(function(){        
            menuMid.css("background-color","rgb(60,60,60)");
            $(this).css("background-color","#fd9d3e");
            return false;

        });
    

    };

    function menuClick(){
        var menuClick = $(".menu-mid ul li");
        menuClick.click(function(){
        
            var target = $(this).attr("target");
            $(".target").addClass("desactive");
            $(target).removeClass("desactive");
            $(target).addClass("active");

            return false;
        })

    }
    menuClick();
    menu();    
     
    
    
}); 



