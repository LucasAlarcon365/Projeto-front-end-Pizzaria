$(function(){
    /*

    function menuClick(){
        var menuClick = $(".menu-mid ul li a");
        menuClick.click(function(){
        
            var href = $(this).attr("href");
            $(".target").addClass("desactive");
            $(href).removeClass("desactive");
            $(href).addClass("active");

            return false;
        })

    }
    menuClick();

    */

    function menuClick(){
        var menuClick = $(".menu-mid ul li");
        menuClick.click(function(){
        
            var target = $(this).attr("target");
            $(".target").addClass("desactive");
            $(target).removeClass("desactive");
            $(target).addClass("active");

            return false;
        })

    }
    menuClick();


})   ;
   
  